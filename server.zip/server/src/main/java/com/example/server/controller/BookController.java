package com.example.server.controller;

import com.example.server.model.Book;
import com.example.server.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {
    @Autowired
    private BookService bookService;

    @GetMapping("/book")
    List<Book> getBookByQuery(@RequestParam String query) {

        return bookService.findBooksByQuery(query);
    }

    @GetMapping("/books")
    List<Book> getAllBooks() {

        return bookService.getAllBooks();
    }
}
